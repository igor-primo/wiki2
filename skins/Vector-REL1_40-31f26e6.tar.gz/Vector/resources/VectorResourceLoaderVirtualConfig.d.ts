/** See Vector\Hooks::getVectorResourceLoaderConfig */
interface VectorResourceLoaderVirtualConfig {
	wgVectorSearchApiUrl: string;
}
